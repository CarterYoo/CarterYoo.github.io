from pathlib import Path
from urllib.request import Request,urlopen
import json,hashlib
base="https://carteryoo.github.io/feature-atlas/atlas/"
root=Path(__file__).resolve().parent/"atlas"
meta=json.loads((root/"manifest.json").read_text())
sem=json.loads((root/"semantic_manifest.json").read_text())
bound=json.loads((root/"boundary_manifest.json").read_text())
files=set()
for model,m in meta["models"].items():
    files.update(m["files"].values())
    s=sem["models"][model]
    files.update([s["group_ids"],s["group_statistics"],bound["models"][model]["file"]])
    for page in range(s["details_pages"]):
        files.add(s["details_pattern"].replace("{page}",str(page).zfill(5)))
for index,name in enumerate(sorted(files)):
    p=root/name;p.parent.mkdir(exist_ok=True,parents=True)
    with urlopen(Request(base+name,headers={"User-Agent":"Mozilla/5.0"})) as response:p.write_bytes(response.read())
    print(f"{index+1}/{len(files)} {name}")
print("Data download complete")
