# Temporal Feature Atlas interface

This archive contains the public atlas interface and metadata. Measured binaries and all 393,216 tag rows remain available from the live site.

1. Run `python3 download_data.py` from this folder to fetch the listed data.
2. Run `python3 -m http.server 8000`.
3. Open http://127.0.0.1:8000/atlas/ .

The UI requires a modern browser with WebGL or Canvas support and DecompressionStream. All temporal coordinates and values are measured and precomputed. Labels are candidate evidence associations.

Released SAE code: https://github.com/jds8/SAE4DLM-CE
